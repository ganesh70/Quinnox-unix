#!/bin/bash
# case construct in unix

echo -e "\t\t\tCalculator Menu "
echo -e "\t\t1.Add "
echo -e "\t\t2.Substract "
echo -e "\t\t3.Multiply "
echo -e "\t\t4.Divide "
echo -e "\t\t5.Exit "
echo
read -p "Enter Choice " ch
echo $ch

case $ch in
1)echo Choice is 1 
  read -p "Enter 2 integers " n1 n2
  echo Addition is `expr $n1 + $n2` ;;
2)echo Choice is 2 
  x=`sh sub.sh`
  echo 'x ' $x;;
3)echo Choice is 3 ;;
4)echo Choice is 4 ;;
5)echo Thank You
  echo Going............
  sleep 3
  clear
  exit
esac



echo Out of Case 

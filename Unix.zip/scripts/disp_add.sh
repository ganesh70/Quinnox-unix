#!/bin/bash

# Script to add two numbers

read -p "Enter Number 1 " no1
read -p "Enter Number 2 " no2
echo Addition is `expr $no1 + $no2`

# Modify the above to display Substraction / Multiplication / Division

echo Substraction is `expr $no1 - $no2`
echo Division is `expr $no1 / 3`
echo Multiplication is `expr $no1 \* $no2`


# Q :  Accept a 4 digit integer - Accept in a single variable 
#   Display : Addition of 1st and 3rd digit
              Product of 2nd and 4th digit
ex 1234 
  -> 4
  -> 8


#!/bin/bash

# Script to check for file Existence
#read -p "Enter File Name " fname

if [ $# -ne 1 ]
then 
   echo Invalid Arguments.......contact admin
else
if [ -f $1 ]
then
  echo File Exists and is Regular - $1
elif [ -d $1 ]
then
  echo Directory File - $1
else
   echo Invalid File	
fi
fi
#-e - file existence
#-f - file existence and is regular
#-d - file existence and is directory

# Ex : Accept File from User and check for Regular or Directory
# Ex : Create a Backup Utility (single file)
# Accept File Name from User and Backup only if it is Non Empty Regular file




#!/bin/bash
# reverse a string

for file in `ls`
do
if [ -f $file ]
then	
   len=`echo $file | wc -L`
  x=$len
  str2=
   while [ $len -gt 0 ]
    do
     str=`echo $file | cut -c$len`
     str2=$str2$str
     len=`expr $len - 1`
    done
echo $file $str2 $x 
fi
done



#!/bin/bash
# loops 

# while loop
# for loop
# until loop

# while loop in unix
# display nos from 1 to 15

if [ $# -ne 1 ]
then 
   echo Invalid Arguments
else
  no=1
  while [ $no -le 10 ]
   do
      echo $1 x $no = `expr $1 \* $no` 
      no=`expr $no + 1`
   done
fi
#Ex : Display multiplication table for the integer (accept integer from command line)
# Program should work for one argument only
# format : 5 x 1 = 5




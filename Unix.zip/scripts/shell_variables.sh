# Shell variables at command line can be from $1 ....... $9

echo First Argument is  '$1 -> ' $1
echo Second Argument is '$2 -> ' $2
echo Third Argument is  '$3 -> ' $3
echo Fourth Argument is '$4 -> ' $4
echo Fifth Argument is  '$5 -> ' $5
echo Six Argument is    '$6 -> ' $6
echo
echo Total Arguments are '$# ->' $#
echo
echo Script Name is '$0 ->' $0
echo
echo List of Arguments by '$* ->' $*
echo

#Ex Write a Script to find a pattern in file
#  Found - if pattern found
#  Not Found - if pattern not found
# Script should execute only for 2 arguments


#!/bin/bash

read -p "Enter 4 digit integer " no
n1=`echo $no | cut -c1`
n2=`echo $no | cut -c2`
n3=`echo $no | cut -c3`
n4=`echo $no | cut -c4`
echo
echo Addition of $n1 and $n3 is `expr $n1 + $n3`
echo Product of $n2 and $n4 is `expr $n2 \* $n4`



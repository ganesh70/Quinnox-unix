#!/bin/bash

# conditional statememnts
# if / case
# conditional operators in unix

# >    -gt
# <    -lt
# >=   -ge
# <=   -le
# !=   -ne
# =    -eq

#logical operators -> -o / -a

# Accept 2 integers and display max

read -p "Enter 1 number " no1
read -p "Enter 2 number " no2

if [ $no1 -gt $no2 ]
then
   echo Max is $no1
else
  echo Max is $no2
fi





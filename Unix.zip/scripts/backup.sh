#!/bin/bash
# Backup Script

read -p "Enter File " fname
if [ -f $fname ]
then
size=`ls -l $fname | tr -s " " | cut -d " " -f5`
  if [ $size -eq 0 ]
  then
     echo Empty File
     rm $fname
   else
     cp $fname /tmp/ganesh_backup/
   fi
elif [ -d $fname ]
then
   echo Directory File $fname
else
   echo Invalid File 
fi


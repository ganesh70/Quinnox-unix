#!/bin/bash
# for loop
#Syntax
# Ex 
#for var in <args>
#do
     

#done


for name in `cat /home/cc-user1/names`
do

	echo Hello Welcome $name to Unix
sleep 1
done

# Ex : Display all filenames and their reverse and their length filenames (regular)
#  age.sh hs.ega 6



#!/bin/bash
while [ $# -gt 0 ]
do
   if [ -f $1 ]
   then
	size=`ls -l $1 | tr -s " " | cut -d " " -f5`
	if [ $size -eq 0 ]
	then
	  rm $1
        else
          cp $1 /tmp/ganesh_backup/
	fi
    elif [ -d $1 ]
    then
      echo Directory File 
    else
      echo Invalid File 
    fi

   shift 

done






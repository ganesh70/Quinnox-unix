#! /bin/bash
# Single line Comment

echo Welcome to Shell Scripts
echo
echo Todays date is
date
echo Calendar for the Month is 
cal
echo
echo Thank You
echo


#!/bin/bash

# Script to accept filename from user and display Size

read -p "Enter File Name " fname

size=`ls -l $fname| tr -s " " | cut -d " " -f5`
echo
echo File Name is $fname and size is $size

# Modify above program to accept 2 filenames and display total size


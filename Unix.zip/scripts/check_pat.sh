#!/bin/bash

if [ $# -ne 2 ]
then
  echo Invalid Arguments......
else
 grep $1 $2 > test_file
 cnt=`cat test_file|wc -l`
 if [ $cnt -eq 0 ]
 then
  echo Not Found
 elif [ $cnt -gt 0 ]
 then
   echo Found 
 fi
fi

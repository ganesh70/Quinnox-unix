#!/bin/bash
read -p "Enter 2 integers " n1 n2
expr $n1 - $n2

#!/bin/bash

read -p 'Enter Year of Birth ' yr
cyr=`date +%Y`
echo Age is `expr $cyr - $yr` 
